# BOSS BOOSTER — Android 9+ (API 28+) starter

Native Kotlin + Jetpack Compose source project. This source revision adds a movable floating overlay and a Shizuku permission/status gate for Ultimate Mode.

## Included
- Black/red dashboard
- Installed launcher-app search and launch buttons
- Battery, memory, battery temperature, and thermal status where available
- Floating overlay that can be dragged by its title and closed
- Android overlay-permission flow (`Display over other apps`)
- Shizuku API dependency, binder check, permission request and official guide shortcut
- Ultimate Mode screen with explicit limitation notices

## Build
1. Install Android Studio and Android SDK Platform 35 or newer.
2. Open this folder in Android Studio and allow Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions / setup
- Overlay: tap **ENABLE / START OVERLAY**, allow Display over other apps in Android Settings, return to the app and tap again.
- Shizuku: install Shizuku from its official site, start its service, then use **CONNECT / REQUEST SHIZUKU PERMISSION**. On non-rooted Android 11+ devices, wireless debugging can start Shizuku; Android 9–10 generally requires a computer/ADB.
- Shizuku grants only the capabilities available to its running ADB/root identity. Permission does not mean every system control is allowed.

## CPU/GPU boost honesty
This starter intentionally does not write to kernel CPU/GPU frequency nodes, change thermal limits, or run arbitrary shell commands. Actual frequency controls are vendor/kernel-specific and may be unavailable or unsafe. Implement a device-specific adapter only after verifying a supported public OEM API or a narrowly scoped operation that is safe on the target device.

## Status
This is source code, not a compiled or device-tested APK. Build and test across Android 9, 11, 13, 15+ and OEM skins before distributing.


## Voice changer compatibility screen
The VOICE tab adds effect-profile selection (Robot, Deep Voice, Alien, High Pitch) and a microphone permission/Android-version readiness check. It deliberately does not claim to alter another game's microphone stream: stock Android generally does not expose a universal API for injecting processed microphone audio into other apps. True live in-game voice changing requires OEM/system integration or game-specific support.
