# Build BOSS BOOSTER APK on GitHub (phone-only)

1. Extract this ZIP on your phone.
2. Upload the *contents* of this folder to the root of your GitHub repository (not the ZIP file itself). Keep `.github/workflows/build.yml` in that exact path.
3. Commit the files to `main`.
4. Open the repository's **Actions** tab. Choose **Build BOSS BOOSTER APK** and select **Run workflow** if it has not started automatically.
5. Open the successful run and download **BOSS-BOOSTER-debug-APK** under **Artifacts**. Extract that artifact ZIP to get the `.apk`.

The workflow uses Java 17, installs Android SDK packages non-interactively, and aligns Java/Kotlin JVM targets at 17. It avoids the `android-actions/setup-android@v3` step that previously failed in the user's runner.

This is a debug build workflow; it does not guarantee all app features work on every device. Live voice-changing inside third-party games is not implemented by this starter project.
